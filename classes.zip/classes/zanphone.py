import requests
from bs4 import BeautifulSoup

class Zanphone():
    def __init__(self):
        self.outputObject = []

    def getData(self, url, name, driver):
        try:
            driver.get(url)
            html = driver.page_source
            soup = BeautifulSoup(html, 'html.parser')   
            price_element = soup.select_one('p.price')
            price = price_element.contents[0].contents[0].get_text().replace('€', '').replace(',', '.').strip()
            return [str(name).strip(), float(price)]
                
        except Exception as e:
            return print('Erreur :', e)
        
        # Si aucun schéma ne renvoie de prix, renvoyer None
        return None
